import App from "./app";
// import Graph from "../../lib";

// import Graph from 'react-graph-vis'

import React from "react";
import { render } from "react-dom";

render(
  <div className="">

    <App />
  </div>,
  document.getElementById("root")
);